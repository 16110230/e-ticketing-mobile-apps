import * as Ticket from './ticket'
import * as Dashboard from './dashboard'
import * as Login from './login'
import * as Profile from './profile'
import * as Redux from './redux'

export {
        Ticket, 
        Dashboard, 
        Login, 
        Profile, 
        Redux
    } 